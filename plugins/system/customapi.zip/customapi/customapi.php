<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Response\JsonResponse;

class PlgSystemCustomapi extends CMSPlugin
{
    public function onAfterRoute()
    {
        $app = Factory::getApplication();

        // Check if it's the frontend and a custom API request
        if ($app->isClient('site') && $app->input->get('customapi', false)) {
            $this->addCorsHeaders();
            $this->handleApiRequest();
            $app->close();
        }
    }

    protected function addCorsHeaders()
    {
        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
        header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
    }

    protected function handleApiRequest()
    {
        $input = Factory::getApplication()->input;
        $task = $input->getCmd('task');

        switch ($task) {
            case 'getDocuments':
                $this->getDocuments();
                break;
            case 'getRsCategory':
                $this->getRsCategory();
                break;
            case 'saveViewed':
                $this->saveViewed();
                break;
            case 'saveDownloaded':
                $this->saveDownloaded();
                break;
            default:
                echo new JsonResponse(null, 'Invalid task', true);
                break;
        }
    }

    protected function saveViewed()
    {
        try {
            $input = Factory::getApplication()->input;
            $fileId = $input->json->getInt('file_id');
            $viewerIpAddress = $input->server->get('REMOTE_ADDR');
            $viewerCountry = $this->getCountryFromIp($viewerIpAddress);

            if (!$viewerCountry) {
                $viewerCountry = 'Unknown';
            }

            $db = Factory::getDbo();
            $query = $db->getQuery(true)
                ->insert($db->quoteName('lanl4_lanl_rsfiles_viewed'))
                ->columns(array($db->quoteName('file_id'), $db->quoteName('viewer_ip_address'), $db->quoteName('viewer_country'), $db->quoteName('date_viewed')))
                ->values(implode(',', array($db->quote($fileId), $db->quote($viewerIpAddress), $db->quote($viewerCountry), 'CURDATE()')));
            
            $db->setQuery($query);
            $db->execute();

            echo new JsonResponse(array('success' => true));
        } catch (Exception $e) {
            echo new JsonResponse(null, $e->getMessage(), true);
        }
    }

    protected function saveDownloaded()
    {
        try {
            $input = Factory::getApplication()->input;
            $fileId = $input->json->getInt('file_id');
            $downloaderIpAddress = $input->server->get('REMOTE_ADDR');
            $downloaderCountry = $this->getCountryFromIp($downloaderIpAddress);

            if (!$downloaderCountry) {
                $downloaderCountry = 'Unknown';
            }

            $db = Factory::getDbo();
            $query = $db->getQuery(true)
                ->insert($db->quoteName('lanl4_lanl_rsfiles_downloaded'))
                ->columns(array($db->quoteName('file_id'), $db->quoteName('downloader_ip_address'), $db->quoteName('downloader_country'), $db->quoteName('date_downloaded')))
                ->values(implode(',', array($db->quote($fileId), $db->quote($downloaderIpAddress), $db->quote($downloaderCountry), 'CURDATE()')));
            
            $db->setQuery($query);
            $db->execute();

            echo new JsonResponse(array('success' => true));
        } catch (Exception $e) {
            echo new JsonResponse(null, $e->getMessage(), true);
        }
    }

    protected function getCountryFromIp($ipAddress)
    {
        $apiKey = 'YOUR_API_KEY'; // Replace with your ipstack API key
        $url = 'http://api.ipstack.com/' . $ipAddress . '?access_key=' . $apiKey;

        try {
            $http = \Joomla\CMS\Http\HttpFactory::getHttp();
            $response = $http->get($url);

            if ($response->code == 200) {
                $data = json_decode($response->body);
                if (!empty($data->country_name)) {
                    return $data->country_name;
                }
            }
        } catch (Exception $e) {
            return null;
        }

        return null;
    }



    
    protected function getDocuments()
    {
        try {
            $db = Factory::getDbo();
            $query = $db->getQuery(true)
                ->select('IdFile, hits, FilePath, Downloads, DateAdded, SUBSTRING_INDEX(FilePath, "/", -1) AS FileName, SUBSTRING(FilePath, 1, LENGTH(FilePath) - LENGTH(SUBSTRING_INDEX(FilePath, "/", -1)) - 1) AS Category')
                ->from($db->quoteName('lanl4_rsfiles_files'));
    
            // Check for filter parameters
            $input = Factory::getApplication()->input;
            $startDate = $db->escape($input->getString('startDate', ''));
            $endDate = $db->escape($input->getString('endDate', ''));
            $sortBy = $db->escape($input->getString('sortBy', ''));
    
            // Apply date range filter
            if (!empty($startDate) && !empty($endDate)) {
                $query->where('DateAdded BETWEEN ' . $db->quote($startDate) . ' AND ' . $db->quote($endDate));
            }
    
            // Apply sorting
            if ($sortBy == 'mostViewed') {
                $query->order('hits DESC');
            } elseif ($sortBy == 'mostDownloaded') {
                $query->order('Downloads DESC');
            }
    
            $db->setQuery($query);
            $files = $db->loadObjectList();
    
            echo new JsonResponse($files);
        } catch (Exception $e) {
            echo new JsonResponse(null, $e->getMessage(), true);
        }
    }
    




  
    protected function getRsCategory()
{
    try {
        $db = Factory::getDbo();
        $query = $db->getQuery(true)
            ->select('FilePath, SUM(hits) AS totalHits, SUM(Downloads) AS totalDownloads, GROUP_CONCAT(SUBSTRING_INDEX(FilePath, "/", -1)) AS FileNames, SUBSTRING(FilePath, 1, LENGTH(FilePath) - LENGTH(SUBSTRING_INDEX(FilePath, "/", -1)) - 1) AS Category')
            ->from($db->quoteName('lanl4_rsfiles_files'));

        // Check for filter parameters
        $input = Factory::getApplication()->input;
        $startDate = $db->escape($input->getString('startDate', ''));
        $endDate = $db->escape($input->getString('endDate', ''));
        $sortBy = $db->escape($input->getString('sortBy', ''));

        // Apply date range filter
        if (!empty($startDate) && !empty($endDate)) {
            $query->where('DateAdded BETWEEN ' . $db->quote($startDate) . ' AND ' . $db->quote($endDate));
        }

        // Apply sorting
        if ($sortBy == 'mostViewed') {
            $query->order('totalHits DESC');
        } elseif ($sortBy == 'mostDownloaded') {
            $query->order('totalDownloads DESC');
        }

        $query->group('FilePath');
        
        $db->setQuery($query);
        $files = $db->loadAssocList();

        echo new JsonResponse($files);
    } catch (Exception $e) {
        echo new JsonResponse(null, $e->getMessage(), true);
    }
}

}
